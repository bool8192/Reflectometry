from calculating_dynamic_resolution import *
from convolution import convolution
from variables import *
from read_complex_matrix import *
import torch
import numpy as np


def reflectometry_trace(q, matrix):
    """
    Анализ спектра отражательной способности с поиском экстремумов
    
    Параметры:
    q: сетка волновых векторов
    matrix: матрица описания структуры
    
    Возвращает:
    x_crit: критическая точка
    x_max/y_max: координаты максимумов
    x_min/y_min: координаты минимумов
    ----
    #r: вектор всех значений коэффициента отражения
    #y: вектор всех значений коэффициента отражения со свёрткой
    """
    # Загрузка и расчет базовых матриц
    matr = matrix
    r, r_real, r_img = calculate_matrices_and_reflection(matr, rough_res, kmax, q, Ndots, gap)

    # Свёртка
    y = torch.tensor(convolution(r, kmax, q, Ndots_norm, sigma1, sigma2, gap))
    
    # Поиск критической точки
    below_threshold = torch.where(y < 0.9)[0]
    if len(below_threshold) == 0:
        crit_dot = 0
    else:
        crit_dot = below_threshold[0]
    
    # Поиск локальных экстремумов
    left = y[:-2]
    center = y[1:-1]
    right = y[2:]
    
    max_mask = (center > left) & (center > right)
    min_mask = (center < left) & (center < right)
    
    # Фильтрация индексов
    raw_max_indices = torch.where(max_mask)[0] + 1
    raw_min_indices = torch.where(min_mask)[0] + 1
    
    max_indices = raw_max_indices[raw_max_indices > crit_dot]
    min_indices = raw_min_indices[raw_min_indices > crit_dot]
    
    # Получение координат и их 
    x_max = (q[max_indices])[0:Ndots_trace]
    y_max = (y[max_indices])[0:Ndots_trace]
    x_min = (q[min_indices])[0:Ndots_trace]
    y_min = (y[min_indices])[0:Ndots_trace]
    x_crit =q[crit_dot]

    
    return x_crit, x_max, y_max, x_min, y_min