import torch
def read_complex_matrix(filename):
    device = 'cpu'
    matrix = []
    with open(filename, 'r') as file:
        for line in file:
            values = line.strip('[] \n').split(',')
            row = [complex(x.strip()) for x in values]
            matrix.append(row)
    pt_matrix = torch.tensor(matrix, dtype=torch.complex64, device=device).requires_grad_(True)

    return pt_matrix